# Introduction
Android app to fill out AAE Endodontic case difficulty assessment form. This application is built to digitalize data collection for our upcoming research paper.
It will speed up the form filling procedure and reduce overhead of paper form maintainence.

# Features
 - Firebase
 - Offline disk persistence
